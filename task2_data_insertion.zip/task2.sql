
-- Creating a sample table
CREATE TABLE Students (
    student_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    age INTEGER DEFAULT 18,
    grade TEXT,
    email TEXT
);

-- Inserting data (some with NULLs or default values)
INSERT INTO Students (student_id, name, grade) VALUES (1, 'Alice', 'A');
INSERT INTO Students (student_id, name, age, grade, email) VALUES (2, 'Bob', 21, 'B', 'bob@example.com');
INSERT INTO Students (student_id, name, grade) VALUES (3, 'Carol', 'C');
INSERT INTO Students (student_id, name, grade, email) VALUES (4, 'Charlie', 'B', 'charlie@example.com');

-- Updating a record
UPDATE Students SET age = 20 WHERE name = 'Carol';

-- Deleting a record
DELETE FROM Students WHERE name = 'Charlie';

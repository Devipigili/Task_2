
# Task 2: Data Insertion and Handling Nulls

## Description
This task focuses on practicing SQL operations like INSERT, UPDATE, and DELETE, with special emphasis on handling NULL values.

## What I Did
- Created a table `Students` with columns that allow NULLs and default values.
- Inserted records with full and partial column data.
- Used `DEFAULT`, handled `NULL`, and updated/deleted specific rows.

## Screenshot
See the included output screenshot displaying the `SELECT * FROM Students` result.
